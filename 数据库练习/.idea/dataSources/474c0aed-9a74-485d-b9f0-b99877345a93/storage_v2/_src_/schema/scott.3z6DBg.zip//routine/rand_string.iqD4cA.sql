create function rand_string(n int)
  returns varchar(255)
  begin
    declare chars_str varchar(100) default
      'abcdefghijklmnopqrstuvwxyzABCDEFJHIJKLMNOPQRSTUVWXYZ';
    declare return_str varchar(255) default '';
    declare i int default 0;
    while i < n do
      set return_str =concat(return_str,substring(chars_str,floor(1+rand()*52),1));
      set i = i + 1;
    end while;
    return return_str;
  end;

