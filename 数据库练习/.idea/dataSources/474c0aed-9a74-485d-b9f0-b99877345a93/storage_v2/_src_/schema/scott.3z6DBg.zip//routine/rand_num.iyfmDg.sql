create function rand_num()
  returns int(5)
  begin
  declare i int default 0;
set i = floor(10+rand()*500);
return i;
end;

